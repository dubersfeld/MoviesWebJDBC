package com.dub.exceptions;



public class DuplicateActorException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
}
