package com.dub.exceptions;



public class PhotoNotFoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
}
