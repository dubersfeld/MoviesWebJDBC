package com.dub.exceptions;



public class DuplicateEntryException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
}

