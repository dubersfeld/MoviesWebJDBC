package com.dub.exceptions;



public class DuplicateDirectorException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
}
