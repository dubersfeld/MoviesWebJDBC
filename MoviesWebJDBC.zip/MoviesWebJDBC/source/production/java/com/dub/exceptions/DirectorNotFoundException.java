package com.dub.exceptions;



public class DirectorNotFoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
}
