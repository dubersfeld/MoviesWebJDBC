package com.dub.exceptions;



public class DuplicateMovieException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	
}
